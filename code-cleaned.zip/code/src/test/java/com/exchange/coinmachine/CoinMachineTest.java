package com.exchange.coinmachine;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class CoinMachineTest {
	
	@Autowired
    private MockMvc mockMvc;
	
    @Test
    public void testChangeBillToLeastCoins() throws Exception {
    	StringBuilder url = new StringBuilder("/change").append("?bill=").append(1).append("&leastCoins=").append(true);
        mockMvc.perform(post(url.toString()))
                .andExpect(jsonPath("$.success").value(true));
    }
	
    @Test
    public void testChangeBillToMostCoins() throws Exception {
    	StringBuilder url = new StringBuilder("/change").append("?bill=").append(1).append("&leastCoins=").append(false);
        mockMvc.perform(post(url.toString()))
                .andExpect(jsonPath("$.success").value(true));
    }
	
    @Test
    public void testChangeInvalidBill() throws Exception {
    	StringBuilder url = new StringBuilder("/change").append("?bill=").append(13).append("&leastCoins=").append(false);
        mockMvc.perform(post(url.toString()))
        		.andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Invalid Bill Passed"));
    }
	
    @Test
    public void testChangeInsufficientCoins() throws Exception {
    	StringBuilder url = new StringBuilder("/change").append("?bill=").append(100).append("&leastCoins=").append(false);
        mockMvc.perform(post(url.toString()))
        		.andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Insufficinet Coins"));
    }
    
    

}
