package com.exchange.coinmachine.exceptions;

public class InvalidBillException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidBillException(String message) {
		super(message);
	}
}
