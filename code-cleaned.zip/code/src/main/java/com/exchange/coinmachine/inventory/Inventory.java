package com.exchange.coinmachine.inventory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import com.exchange.coinmachine.denominations.BillDenomination;
import com.exchange.coinmachine.denominations.CoinDenominations;
import com.exchange.coinmachine.model.Transaction;
import com.exchange.coinmachine.model.TransactionResult;
import com.exchange.coinmachine.util.Util;

public class Inventory {
	private static final Logger logger = Logger.getLogger(Inventory.class.getName());

	private Map<CoinDenominations, Integer> coins = new HashMap<CoinDenominations, Integer>();
	private List<Transaction> transactions = new ArrayList<Transaction>();

	private static int DEFAULT = 100;

	private static Inventory INSTANCE;

	private Inventory() {

	}

	public static Inventory getInstance() {
		if (INSTANCE == null) {
			synchronized (Inventory.class) {
				if (INSTANCE == null) {
					INSTANCE = new Inventory();
					INSTANCE.initializeInventory();
				}
			}
		}
		return INSTANCE;
	}

	public void initializeInventory() {
		logger.info("Starting Inventory Initialization");
		Properties properties = new Properties();
		try {
			properties = Util.loadProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		coins.put(CoinDenominations.ONE_CENT,
				Integer.parseInt((String) properties.getOrDefault("machine.coins.onecent", DEFAULT)));
		coins.put(CoinDenominations.FIVE_CENT,
				Integer.parseInt((String) properties.getOrDefault("machine.coins.fivecent", DEFAULT)));
		coins.put(CoinDenominations.TEN_CENT,
				Integer.parseInt((String) properties.getOrDefault("machine.coins.tencent", DEFAULT)));
		coins.put(CoinDenominations.QUARTER_CENT,
				Integer.parseInt((String) properties.getOrDefault("machine.coins.quartercent", DEFAULT)));
		logger.info(coins.toString());
		logger.info("Inventory Initialization Complete");
	}
	
	public int getState(CoinDenominations coin) {
		return coins.getOrDefault(coin, 0);
	}
	
	public void remove(int number, CoinDenominations coin) {
		coins.put(coin, coins.get(coin) - number);
	}
	
	public synchronized TransactionResult transact(BillDenomination bill, boolean leastCoins) {
		Transaction tran = new Transaction();
		tran.setBill(bill);
		boolean status = leastCoins ? transactUsingLeastCoins(tran) : transactUsingMostCoins(tran);
		if(status) {
			tran.setDate(new Date());
			transactions.add(tran);
			tran.getCoins().entrySet().forEach(entry -> {
				remove(entry.getValue(), entry.getKey());
			});
			return new TransactionResult().prepareResultFromTransaction(tran);
		} else {
			return new TransactionResult().prepareFailedResult("Insufficinet Coins");
		}
	}

	private boolean transactUsingMostCoins(Transaction tran) {
		int bill = tran.getBill().getValue() * 100;
		bill = checkDenom(CoinDenominations.ONE_CENT, 1, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.FIVE_CENT, 5, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.TEN_CENT, 10, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.QUARTER_CENT, 25, tran, bill);
		return bill == 0;
	}
	
	public int checkDenom(CoinDenominations denom, int denomValue, Transaction tran, int bill) {
		if(getState(denom) > 0)
		if(bill <= getState(denom) * denomValue) {
			tran.getCoins().put(denom, bill/denomValue);
			bill = 0;
		} else {
			int coins = getState(denom);
			bill = bill - coins*denomValue;
			tran.getCoins().put(denom, coins);
		}
		return bill;
	}

	private boolean transactUsingLeastCoins(Transaction tran) {
		int bill = tran.getBill().getValue() * 100;
		bill = checkDenom(CoinDenominations.QUARTER_CENT, 25, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.TEN_CENT, 10, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.FIVE_CENT, 5, tran, bill);
		if(bill == 0) return true;
		bill = checkDenom(CoinDenominations.ONE_CENT, 1, tran, bill);
		return bill == 0;
	}
	
	public void exitIfMachineEmpty() {
		for( CoinDenominations c : CoinDenominations.values()) {
			if(getState(c) > 0) return;
		}
		logger.info("Coin machine empty. Shutting doen");
		System.exit(1);
	}
	
	public List<Transaction> getTransactions() {
		return new ArrayList<Transaction>(transactions);
	}
	
	public Map<CoinDenominations, Integer> getMachineState() {
		return new HashMap<CoinDenominations, Integer>(coins);
	}
}
