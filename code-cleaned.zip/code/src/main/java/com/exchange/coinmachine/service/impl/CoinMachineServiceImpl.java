package com.exchange.coinmachine.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.exchange.coinmachine.denominations.BillDenomination;
import com.exchange.coinmachine.denominations.CoinDenominations;
import com.exchange.coinmachine.exceptions.InvalidBillException;
import com.exchange.coinmachine.inventory.Inventory;
import com.exchange.coinmachine.model.Transaction;
import com.exchange.coinmachine.model.TransactionResult;
import com.exchange.coinmachine.service.CoinMachineService;

@Service
public class CoinMachineServiceImpl implements CoinMachineService {
	
	@Override
	public TransactionResult getChangeForBill(int bill, boolean leastCoins) {
		try {
		BillDenomination denom = BillDenomination.verifyBill(bill);
		return Inventory.getInstance().transact(denom, leastCoins);
		} catch(InvalidBillException e) {
			e.printStackTrace();
			return new TransactionResult().prepareFailedResult(e.getMessage());
		}
	}
	
	@Override
	public List<Transaction> getAllTransactions() {
		return Inventory.getInstance().getTransactions();
	}
	
	@Override
	public Map<CoinDenominations, Integer> getMachineState() {
		return Inventory.getInstance().getMachineState();
	}
}
