package com.exchange.coinmachine.model;

import java.util.HashMap;
import java.util.Map;

public class TransactionResult {

	private boolean success;
	private String error = "";
	private Map<String, Integer> coins = new HashMap<String, Integer>();

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public Map<String, Integer> getCoins() {
		return coins;
	}

	public void setCoins(Map<String, Integer> coins) {
		this.coins = coins;
	}

	public TransactionResult prepareResultFromTransaction(Transaction transaction) {
		success = true;
		transaction.getCoins().entrySet().forEach(entry -> {
			coins.put(entry.getKey().getLabel(), entry.getValue());
		});
		return this;
	}
	
	public TransactionResult prepareFailedResult(String errorMessage) {
		error = errorMessage;
		return this;
	}
}
