package com.exchange.coinmachine.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.exchange.coinmachine.denominations.CoinDenominations;
import com.exchange.coinmachine.model.Transaction;
import com.exchange.coinmachine.model.TransactionResult;
import com.exchange.coinmachine.service.CoinMachineService;

@RestController
public class CoinMachineRestController {
	
	@Autowired
	CoinMachineService service;
	
	@PostMapping("/change")
	public TransactionResult changeBill(@RequestParam int bill, @RequestParam boolean leastCoins) {
		return service.getChangeForBill(bill, leastCoins);
	}
	
	@PostMapping("/transactions")
	public List<Transaction> allTransactions() {
		return service.getAllTransactions();
	}
	
	@PostMapping("/machineState")
	public Map<CoinDenominations, Integer> machineState() {
		return service.getMachineState();
	}
}
