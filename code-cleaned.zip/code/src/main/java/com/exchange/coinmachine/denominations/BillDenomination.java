package com.exchange.coinmachine.denominations;

import com.exchange.coinmachine.exceptions.InvalidBillException;

public enum BillDenomination {
	ONE_DOLLAR(1),
	TWO_DOLLAR(2),
	FIVE_DOLLAR(5),
	TEN_DOLLAR(10),
	TWENTY_DOLLAR(20),
	FIFTY_DOLLAR(50),
	HUNDRED_DOLLAR(100);
	
	private int value;

	public int getValue() {
		return this.value;
	}

	private BillDenomination(int value) {
		this.value = value;
	}
	
	public static BillDenomination verifyBill(int value) {
		for(BillDenomination bill : BillDenomination.values()) {
			if(bill.getValue() == value) return bill;
		}
		throw new InvalidBillException("Invalid Bill Passed");
	}
}
