package com.exchange.coinmachine.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.exchange.coinmachine.inventory.Inventory;

public class Util {
	
	public static Properties loadProperties() throws IOException {
		Properties configuration = new Properties();
		InputStream inputStream = Inventory.class.getClassLoader().getResourceAsStream("application.properties");
		configuration.load(inputStream);
		inputStream.close();
		return configuration;
	}

}
