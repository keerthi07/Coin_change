package com.exchange.coinmachine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.exchange.coinmachine.inventory.Inventory;


@SpringBootApplication
@EnableAutoConfiguration
public class CoinMachine extends SpringBootServletInitializer {
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CoinMachine.class);
    }
		
	public static void main(String[] args) {
		  SpringApplication.run(CoinMachine.class, args);
		  Inventory.getInstance().initializeInventory();
	}
}
