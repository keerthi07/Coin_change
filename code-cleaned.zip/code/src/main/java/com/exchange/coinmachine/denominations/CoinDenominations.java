package com.exchange.coinmachine.denominations;

public enum CoinDenominations {
	ONE_CENT("One Cent"), FIVE_CENT("Five Cent"), TEN_CENT("Ten Cent"), QUARTER_CENT("Quarter Cent");

	private String label;

	public String getLabel() {
		return this.label;
	}

	private CoinDenominations(String label) {
		this.label = label;
	}
}
