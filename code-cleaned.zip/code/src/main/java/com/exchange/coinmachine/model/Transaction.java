package com.exchange.coinmachine.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.exchange.coinmachine.denominations.BillDenomination;
import com.exchange.coinmachine.denominations.CoinDenominations;

public class Transaction {
	private Map<CoinDenominations, Integer> coins = new HashMap<CoinDenominations, Integer>();
	private BillDenomination bill;
	private Date date;
	public Map<CoinDenominations, Integer> getCoins() {
		return coins;
	}
	public void setCoins(Map<CoinDenominations, Integer> coins) {
		this.coins = coins;
	}
	public BillDenomination getBill() {
		return bill;
	}
	public void setBill(BillDenomination bill) {
		this.bill = bill;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
}
