package com.exchange.coinmachine.service;

import java.util.List;
import java.util.Map;

import com.exchange.coinmachine.denominations.CoinDenominations;
import com.exchange.coinmachine.model.Transaction;
import com.exchange.coinmachine.model.TransactionResult;

public interface CoinMachineService {

	TransactionResult getChangeForBill(int bill, boolean leastCoins);

	List<Transaction> getAllTransactions();

	Map<CoinDenominations, Integer> getMachineState();

}
